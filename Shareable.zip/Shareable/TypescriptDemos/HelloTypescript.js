var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var x = 10; // type inference
//x = "Hello World !";
var str; // type annotation
var boolVar;
var num;
var y;
var z;
z = 10;
z = "Bye";
z = { name: 'Synechron' };
function Add(x, y) {
    return x + y;
}
var result = Add(20, 30);
if (true) {
    var a = 1000;
}
// let aVar:number;
// aVar = 100000;
// // 100 lines of code
// let aVar:number;
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 200; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.Accelerate = function () {
        console.log(this.name + " is running at " + this.speed + " kmph !");
    };
    return Car;
}());
// var carObj:Car = new Car();
// carObj.Accelerate();
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(name, speed, fly, submerge) {
        var _this = _super.call(this, name, speed) || this;
        _this.canFly = fly;
        _this.canSubmerge = submerge;
        return _this;
    }
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Houston", 400, true, false);
// var book:IBook = {title:'Wings Of Fire',price:400,author:'Dr. APJ Abdul Kalam'};
var Book = /** @class */ (function () {
    function Book() {
    }
    Book.prototype.getdetails = function () {
        console.log(this.title + " is written by" + this.author);
    };
    return Book;
}());
