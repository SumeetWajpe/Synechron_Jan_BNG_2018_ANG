let b = 1000;


function Product(x:any,y:any){
    return x * y;
}