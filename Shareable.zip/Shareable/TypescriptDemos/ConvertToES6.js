let b = 1000;
function Product(x, y) {
    return x * y;
}
