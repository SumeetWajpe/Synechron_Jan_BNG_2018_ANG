var x = 10;  // type inference
//x = "Hello World !";

var str:string; // type annotation
var boolVar:boolean;
var num:number;
var y;
var z:any;
z = 10;
z = "Bye";
z = {name:'Synechron'};


function Add(x:number,y:number):number{
    return x + y;
}

var result:number = Add(20,30);

if(true){
    let a = 1000;
}


// let aVar:number;
// aVar = 100000;
// // 100 lines of code

// let aVar:number;


class Car{
    // private name:string;
    
    name:string;
    speed:number;
        constructor(name:string="i20",speed:number=200){
                this.name = name;
                this.speed = speed;
}

Accelerate():void{
        console.log(this.name + " is running at " + this.speed + " kmph !")
}
}
// var carObj:Car = new Car();
// carObj.Accelerate();


class JamesBondCar extends Car{
    canFly:boolean;
    canSubmerge:boolean;

    constructor(name:string,speed:number,fly:boolean,submerge:boolean){
        super(name,speed);
        this.canFly= fly;
        this.canSubmerge = submerge;
    }
}

var jbc:JamesBondCar = new JamesBondCar("Houston",400,true,false);


interface IBook{
    title:string;
    price:number;
    author?:string;
    getdetails():void;
}

// var book:IBook = {title:'Wings Of Fire',price:400,author:'Dr. APJ Abdul Kalam'};

class Book implements IBook{
    title:string;
    price:number;
    author:string;
    publication:string;
    getdetails():void{
        console.log(this.title + " is written by" + this.author);
    }
}
