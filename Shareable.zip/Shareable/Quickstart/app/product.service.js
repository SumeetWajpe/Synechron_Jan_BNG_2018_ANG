"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ProductService = (function () {
    function ProductService() {
        this.listOfProducts = ['Laptop', 'Mobile', 'Watch'];
    }
    ProductService.prototype.getAllProducts = function () {
        return this.listOfProducts;
    };
    ProductService.prototype.getRandomProduct = function () {
        return this.listOfProducts[Math.floor(Math.random() * this.listOfProducts.length)];
    };
    ProductService.prototype.addAnewProduct = function (aNewProduct) {
        this.listOfProducts.push(aNewProduct);
    };
    return ProductService;
}());
exports.ProductService = ProductService;
//# sourceMappingURL=product.service.js.map