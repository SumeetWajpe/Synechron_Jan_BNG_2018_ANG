import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {HttpModule} from'@angular/http';
import {RouterModule,Routes} from '@angular/router';


import { AppComponent }  from './app.component';
import { CourseComponent } from './course.component';
import { ShoppingCartComponent } from './shoppingcart.component';
import { ProductComponent } from './product.component';
import { UseProductServiceComponent } from './useproductservice.component';
import { ProductService } from './product.service';
import { PostComponent } from './post.component';
import { StockDuration } from './duration.pipe';
import { ProductStyleDirective } from './productstyle.directive';
import { PostDetailComponent } from './postdetail.component';


const routes:Routes = [
  {path:'posts',component:PostComponent},
  {path:'post/:id',component:PostDetailComponent},  
  {path:'cart',component:ShoppingCartComponent}  
];


@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(routes) ],
  declarations: [ AppComponent, ProductStyleDirective, StockDuration, CourseComponent,ShoppingCartComponent,ProductComponent,PostDetailComponent ,UseProductServiceComponent,PostComponent],
  bootstrap:    [ AppComponent ],
  providers:[ProductService],

})
export class AppModule { }
