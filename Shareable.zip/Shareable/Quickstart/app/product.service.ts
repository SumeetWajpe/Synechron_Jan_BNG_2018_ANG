export class ProductService{
    listOfProducts:string[]=['Laptop','Mobile','Watch'];

    getAllProducts():string[]{
        return this.listOfProducts;
    }

    getRandomProduct():string{
            return this.listOfProducts[Math.floor(Math.random() * this.listOfProducts.length)];
    }

        addAnewProduct(aNewProduct:string){
                this.listOfProducts.push(aNewProduct);
        }

}