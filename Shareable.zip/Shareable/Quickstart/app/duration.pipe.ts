
import {Pipe,PipeTransform} from '@angular/core';

@Pipe({
    name:'duration'
})
export class StockDuration implements PipeTransform {
        transform(inputData:string,args:string){
                return inputData + " " + args;
        }
}