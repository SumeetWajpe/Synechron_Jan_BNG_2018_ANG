
import {Directive,ElementRef,Input,HostListener} from '@angular/core';

@Directive({
    selector:'[productStyle]'
})
export class ProductStyleDirective{

    @Input('productcolor') passedColor:string = "orange";
    constructor(private refElem:ElementRef){
}
    ngOnInit(){
        this.refElem.nativeElement.style.border = "2px solid red";
        this.refElem.nativeElement.style.margin = "20px";
        this.refElem.nativeElement.style.padding = "20px";
        this.refElem.nativeElement.style.borderRadius = "20px";    
        this.refElem.nativeElement.style.backgroundColor = this.passedColor;     
        
    }

    @HostListener('mouseenter') onMouse_Enter(){
        this.refElem.nativeElement.style.backgroundColor = "orange";       
    }

    @HostListener('mouseleave') onMouse_Leave(){
        this.refElem.nativeElement.style.backgroundColor = this.passedColor;     
    }
}