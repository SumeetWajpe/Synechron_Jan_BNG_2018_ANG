
import {Component} from '@angular/core'
import { ActivatedRoute } from '@angular/router';


@Component({
selector:`postdetail`,
template:`<h1> Post Details for {{postId}}  </h1>
            
`
})
export class PostDetailComponent{
    postId:number;
   constructor(private route:ActivatedRoute){

   }

   ngOnInit(){
       this.route.params.subscribe(
           p => this.postId = p["id"]
       )

   }
}