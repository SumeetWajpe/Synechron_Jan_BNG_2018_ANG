
import {Component,Input} from '@angular/core'


@Component({
selector:`product`,
template:`

<div productStyle  [productcolor]="'yellow'">
<h2> {{prodDetails.name | uppercase }} </h2>
<img [src]="prodDetails.ImageUrl" height="200px" width="200px"  /> <br/>
                

Is Free ? : <input type="checkbox" [(ngModel)]="prodDetails.isFree" /> <br/>
<p *ngIf="!prodDetails.isFree">
<b> Price :  </b> {{prodDetails.price | currency:'INR':true }} 
</p>
                <b> Quantity :  </b> {{prodDetails.quantity}} <br/>
                <b> Duration :  </b> {{prodDetails.stocksDuration | duration:'Months' }} <br/>
                
                <b> Rating :  </b> {{prodDetails.rating | number:'1.1-2' }} <br/>
               <b>RAW Data : </b> {{prodDetails | json}}<br/>

    </div> 
`
})
export class ProductComponent{
     @Input()   prodDetails={};
}