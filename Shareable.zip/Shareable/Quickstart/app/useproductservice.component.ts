import {Component} from '@angular/core';
import {ProductService} from './product.service'

@Component({
        selector:`useproductserv`,
        // providers:[ProductService],
        template:`        
       
        <div style="width:500px;border:2px solid red;border-radius:10px;padding:20px;margin:20px;">
        
        <h1>Products from Service </h1>   
        <input type="text" [(ngModel)]="productToBeAdded" /> {{productReceived}}  <br/><br/>
       <input type="button" (click)="AddProduct()" value="Add Product>>" class="btn btn-primary" />
       <input type="button" (click)="GetProduct()" value="Get Random Product" class="btn btn-danger" />    
    </div>
        `
})
export class UseProductServiceComponent{
    productToBeAdded:string="";  
    productReceived:string="";
    constructor(private servObj:ProductService){           
    }
        AddProduct(){
        this.servObj.addAnewProduct(this.productToBeAdded);
    }    
    GetProduct(){
      this.productReceived =   this.servObj.getRandomProduct();
    }

}