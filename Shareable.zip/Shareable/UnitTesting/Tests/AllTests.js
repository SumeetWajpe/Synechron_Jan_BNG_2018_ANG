describe("A suite", function() {
    it("contains spec with an expectation", function() {
      expect(false).toBe(true);
    });
  });

  function Add(x,y){
      return x + y;
  }

  describe("A suite for addition", function() {
    it("adds two numbers", function() {
      expect(Add(20,30)).toBe(50);
    });
  });
